def desvio_estandar():
    print('desviación estandar')